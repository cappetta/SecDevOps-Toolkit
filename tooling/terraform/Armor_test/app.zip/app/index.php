<?php> 
echo HelloWorld;
phpinfo();
<?>
